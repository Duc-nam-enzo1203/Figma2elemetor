/**
 * F2E Bridge — Elementor Editor Integration
 *
 * 1. Registers `$e.run('f2e-bridge/insert', { elements })` to programmatically insert
 *    Figma-compiled containers and widgets into the open Elementor Editor canvas.
 * 2. Automatically intercepts Data-URI base64 images when pasting from Figma Clipboard (`Ctrl+V`),
 *    uploads them via `/wp-json/f2e-bridge/v1/assets` with SHA-256 deduplication, and replaces
 *    the temporary Data-URI with a real WordPress Media Library `{ id, url }` attachment!
 */

(function ($) {
  'use strict';

  if (typeof window === 'undefined') return;

  const f2eEditorBridge = {
    _uploadCache: new Map(),

    async uploadDataUriIfNeeded(dataUri, title = 'Figma Pasted Asset') {
      if (!dataUri || typeof dataUri !== 'string' || !dataUri.startsWith('data:image/')) {
        return null;
      }
      if (this._uploadCache.has(dataUri)) {
        return this._uploadCache.get(dataUri);
      }
      const match = /^data:(image\/[a-z0-9.+-]+);base64,(.+)$/i.exec(dataUri);
      if (!match) return null;

      const uploadPromise = (async () => {
        try {
          const res = await fetch(`${window.f2eEditorConfig?.restUrl || '/wp-json/f2e-bridge/v1'}/assets`, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'X-WP-Nonce': window.f2eEditorConfig?.nonce || '',
            },
            body: JSON.stringify({
              sha256: '',
              mime: match[1],
              base64: match[2],
              name: title,
            }),
          });
          const json = await res.json();
          if (json && json.success && json.data && json.data.id) {
            return { id: json.data.id, url: json.data.url };
          }
        } catch (e) {
          console.warn('[F2E Bridge] Could not auto-upload pasted Data-URI asset:', e);
        }
        return null;
      })();

      this._uploadCache.set(dataUri, uploadPromise);
      return uploadPromise;
    },

    async hydrateElementAssets(element) {
      if (!element || typeof element !== 'object') return element;
      const settings = element.settings || {};
      const title = settings._title || 'Figma Asset';

      const tasks = [];
      const mediaKeys = ['image', 'background_image', '_background_image', 'custom_image', 'bg_image', 'testimonial_image'];
      for (const key of mediaKeys) {
        if (settings[key] && typeof settings[key].url === 'string' && settings[key].url.startsWith('data:image/')) {
          tasks.push(
            this.uploadDataUriIfNeeded(settings[key].url, `${title} ${key}`).then((uploaded) => {
              if (uploaded) settings[key] = uploaded;
            })
          );
        }
      }

      // Check slides and gallery
      if (Array.isArray(settings.slides)) {
        for (const slide of settings.slides) {
          if (slide && slide.background_image && typeof slide.background_image.url === 'string' && slide.background_image.url.startsWith('data:image/')) {
            tasks.push(
              this.uploadDataUriIfNeeded(slide.background_image.url, `${title} Slide BG`).then((uploaded) => {
                if (uploaded) slide.background_image = uploaded;
              })
            );
          }
        }
      }
      if (Array.isArray(settings.gallery)) {
        for (const item of settings.gallery) {
          if (item && typeof item.url === 'string' && item.url.startsWith('data:image/')) {
            tasks.push(
              this.uploadDataUriIfNeeded(item.url, `${title} Gallery Item`).then((uploaded) => {
                if (uploaded) {
                  item.id = uploaded.id;
                  item.url = uploaded.url;
                }
              })
            );
          }
        }
      }

      if (Array.isArray(element.elements) && element.elements.length > 0) {
        tasks.push(Promise.all(element.elements.map((child) => this.hydrateElementAssets(child))));
      }
      if (tasks.length > 0) {
        await Promise.all(tasks);
      }
      return element;
    },

    async insertElements(elements) {
      if (typeof elementor === 'undefined' || typeof $e === 'undefined') {
        console.error('[F2E Bridge] Elementor Editor is not ready.');
        return;
      }
      const list = Array.isArray(elements) ? elements : [];
      const rootContainer = elementor.getPreviewContainer();

      for (const rawEl of list) {
        const el = await this.hydrateElementAssets(JSON.parse(JSON.stringify(rawEl)));
        await $e.run('document/elements/create', {
          container: rootContainer,
          model: el,
          options: { at: -1 },
        });
      }
    },
  };

  window.f2eEditorBridge = f2eEditorBridge;

  // Listen for paste event in Elementor Editor to support instant Ctrl+V of F2E Clipboard JSON
  window.addEventListener('paste', async (event) => {
    const activeTag = document.activeElement?.tagName?.toLowerCase();
    if (activeTag === 'input' || activeTag === 'textarea' || document.activeElement?.isContentEditable) {
      return;
    }
    const text = event.clipboardData?.getData('text/plain') || '';
    if (!text.startsWith('{') || !text.includes('"_f2e_node_id"')) {
      return;
    }
    try {
      const parsed = JSON.parse(text);
      if (parsed && parsed.type === 'elementor' && Array.isArray(parsed.elements)) {
        event.preventDefault();
        await f2eEditorBridge.insertElements(parsed.elements);
      }
    } catch (e) {
      // Not F2E JSON, let Elementor handle normally
    }
  });
})(window.jQuery);
